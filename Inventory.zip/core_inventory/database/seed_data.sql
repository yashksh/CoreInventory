-- ═══════════════════════════════════════════════════════════════
-- CoreInventory — Realistic Seed Data
-- Run AFTER schema.sql. Creates a realistic-looking dataset.
-- ═══════════════════════════════════════════════════════════════

USE core_inventory;

-- ── ADMIN USER (password: admin123) ──────────────────────────
-- Re-insert with a proper hash. Generate yours with:
--   python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('admin123'))"
-- For now we'll let the app handle hashing on signup.

-- ── WAREHOUSES ─────────────────────────────────────────────────
INSERT IGNORE INTO warehouses (id, name, short_code, address) VALUES
(1, 'Main Warehouse',     'WH',   '12 Industrial Estate, Ahmedabad 380015'),
(2, 'North Distribution', 'ND',   '45 Logistics Park, Delhi 110037'),
(3, 'South Hub',          'SH',   '78 Trade Centre, Chennai 600032');

-- ── LOCATIONS ──────────────────────────────────────────────────
INSERT IGNORE INTO locations (id, warehouse_id, name, short_code) VALUES
(1,  1, 'Stock Zone A',   'WH/Stock-A'),
(2,  1, 'Stock Zone B',   'WH/Stock-B'),
(3,  1, 'Receiving Dock',  'WH/Recv'),
(4,  1, 'Shipping Dock',   'WH/Ship'),
(5,  2, 'Shelf 1',         'ND/Shelf-1'),
(6,  2, 'Shelf 2',         'ND/Shelf-2'),
(7,  2, 'Cold Storage',    'ND/Cold'),
(8,  3, 'Bay A',           'SH/Bay-A'),
(9,  3, 'Bay B',           'SH/Bay-B'),
(10, 3, 'Returns Area',    'SH/Returns');

-- ── CONTACTS ───────────────────────────────────────────────────
INSERT IGNORE INTO contacts (id, name, type, email, phone) VALUES
(1,  'Azure Interior',       'vendor',   'sales@azureinterior.com',      '+91 79 2345 6789'),
(2,  'Steel Craft Supplies',  'vendor',   'orders@steelcraft.in',         '+91 22 4567 8901'),
(3,  'TimberWorks India',     'vendor',   'info@timberworks.co.in',       '+91 80 3456 7890'),
(4,  'PackRight Solutions',   'vendor',   'contact@packright.com',        '+91 44 5678 9012'),
(5,  'Nova Electronics',      'vendor',   'procurement@novaelec.in',      '+91 11 6789 0123'),
(6,  'Pinnacle Furnishings',  'customer', 'buying@pinnacle.co.in',        '+91 79 7890 1234'),
(7,  'Metro Office Hub',      'customer', 'orders@metrooffice.com',       '+91 22 8901 2345'),
(8,  'GreenLeaf Interiors',   'customer', 'design@greenleaf.in',          '+91 80 9012 3456'),
(9,  'Skyline Commercial',    'customer', 'procurement@skylinecomm.com',  '+91 11 0123 4567'),
(10, 'Coastal Retail Group',  'customer', 'supply@coastalretail.in',      '+91 44 1234 5678'),
(11, 'Warehouse Team Alpha',  'internal', 'alpha@coreinventory.local',    NULL),
(12, 'Warehouse Team Beta',   'internal', 'beta@coreinventory.local',     NULL);

-- ── PRODUCTS ───────────────────────────────────────────────────
INSERT IGNORE INTO products (id, product_code, name, unit_cost) VALUES
(1,  'DESK001',  'Executive Office Desk',         12500.00),
(2,  'TABLE001', 'Conference Table 8-Seater',      18500.00),
(3,  'CHAIR001', 'Ergonomic Mesh Chair',            8750.00),
(4,  'CHAIR002', 'Visitor Stacking Chair',          2200.00),
(5,  'CAB001',   'Filing Cabinet 4-Drawer',         6800.00),
(6,  'SHELF001', 'Industrial Metal Shelving',        4500.00),
(7,  'MONITOR01','27\" 4K Monitor',                  22000.00),
(8,  'KEYBOARD1','Wireless Keyboard + Mouse',        1800.00),
(9,  'LAMP001',  'LED Desk Lamp Adjustable',         1200.00),
(10, 'WHITEBRD', 'Magnetic Whiteboard 6x4',          3500.00),
(11, 'PROJCTR1', 'HD Projector 4000 Lumens',        35000.00),
(12, 'CABLE001', 'CAT6 Ethernet Cable 50m',           850.00),
(13, 'PAPER01',  'A4 Copier Paper (5 Reams)',          750.00),
(14, 'TONER01',  'Laser Printer Toner Black',        2800.00),
(15, 'LOCK001',  'Combination Padlock Heavy-Duty',     650.00);

-- ── INVENTORY (initial stock at different locations) ───────────
INSERT INTO inventory (product_id, location_id, quantity) VALUES
(1,  1, 45),  (1,  5, 20),  (1,  8, 12),
(2,  1, 30),  (2,  2, 15),  (2,  8, 8),
(3,  1, 120), (3,  5, 60),  (3,  8, 40),
(4,  1, 200), (4,  5, 80),  (4,  9, 50),
(5,  2, 35),  (5,  6, 25),
(6,  2, 50),  (6,  5, 30),  (6,  8, 20),
(7,  1, 80),  (7,  6, 45),
(8,  1, 150), (8,  5, 70),  (8,  9, 35),
(9,  2, 60),  (9,  6, 40),
(10, 1, 25),  (10, 8, 10),
(11, 2, 15),  (11, 9, 5),
(12, 1, 200), (12, 5, 100),
(13, 2, 500), (13, 6, 300), (13, 9, 200),
(14, 2, 40),  (14, 6, 20),
(15, 1, 90),  (15, 5, 60),  (15, 8, 30)
ON DUPLICATE KEY UPDATE quantity = VALUES(quantity);

-- ── STOCK MOVES (for admin user id=1) ──────────────────────────
-- Mix of done, ready, draft, and waiting across receipts/deliveries/internal

-- Done receipts (past)
INSERT INTO stock_moves (id, reference, operation_type, contact_id, from_location_id, to_location_id, schedule_date, status, created_by, created_at) VALUES
(1,  'WH/IN/00001', 'receipt',  1, NULL, 1, '2026-02-10', 'done',    1, '2026-02-10 09:00:00'),
(2,  'WH/IN/00002', 'receipt',  2, NULL, 2, '2026-02-15', 'done',    1, '2026-02-14 14:30:00'),
(3,  'WH/IN/00003', 'receipt',  3, NULL, 5, '2026-02-20', 'done',    1, '2026-02-19 10:00:00'),
(4,  'WH/IN/00004', 'receipt',  5, NULL, 1, '2026-03-01', 'done',    1, '2026-02-28 16:00:00'),
(5,  'WH/IN/00005', 'receipt',  4, NULL, 6, '2026-03-05', 'done',    1, '2026-03-04 11:00:00'),

-- Ready receipts (upcoming)
(6,  'WH/IN/00006', 'receipt',  1, NULL, 1, '2026-03-16', 'ready',   1, '2026-03-12 09:00:00'),
(7,  'WH/IN/00007', 'receipt',  3, NULL, 8, '2026-03-18', 'ready',   1, '2026-03-13 10:00:00'),

-- Draft receipts (upcoming)
(8,  'WH/IN/00008', 'receipt',  2, NULL, 5, '2026-03-20', 'draft',   1, '2026-03-14 08:00:00'),

-- Late receipts (past date, not done)
(9,  'WH/IN/00009', 'receipt',  4, NULL, 2, '2026-03-10', 'ready',   1, '2026-03-08 14:00:00'),
(10, 'WH/IN/00010', 'receipt',  5, NULL, 9, '2026-03-12', 'draft',   1, '2026-03-11 09:00:00'),

-- Waiting receipt
(11, 'WH/IN/00011', 'receipt',  1, NULL, 1, '2026-03-17', 'waiting', 1, '2026-03-14 07:00:00'),

-- Done deliveries (past)
(12, 'WH/OUT/00001', 'delivery', 6, 1, NULL, '2026-02-12', 'done',    1, '2026-02-11 08:00:00'),
(13, 'WH/OUT/00002', 'delivery', 7, 1, NULL, '2026-02-18', 'done',    1, '2026-02-17 09:00:00'),
(14, 'WH/OUT/00003', 'delivery', 8, 5, NULL, '2026-02-25', 'done',    1, '2026-02-24 11:00:00'),
(15, 'WH/OUT/00004', 'delivery', 9, 8, NULL, '2026-03-03', 'done',    1, '2026-03-02 07:00:00'),

-- Ready deliveries (upcoming)
(16, 'WH/OUT/00005', 'delivery', 6, 1, NULL, '2026-03-15', 'ready',   1, '2026-03-13 15:00:00'),
(17, 'WH/OUT/00006', 'delivery', 10, 5, NULL, '2026-03-19', 'ready',  1, '2026-03-14 10:00:00'),

-- Late deliveries
(18, 'WH/OUT/00007', 'delivery', 7, 2, NULL, '2026-03-11', 'ready',   1, '2026-03-09 12:00:00'),
(19, 'WH/OUT/00008', 'delivery', 9, 8, NULL, '2026-03-13', 'draft',   1, '2026-03-12 10:00:00'),

-- Waiting deliveries
(20, 'WH/OUT/00009', 'delivery', 8, 1, NULL, '2026-03-16', 'waiting', 1, '2026-03-14 06:00:00'),
(21, 'WH/OUT/00010', 'delivery', 10, 6, NULL, '2026-03-18', 'waiting', 1, '2026-03-14 08:00:00'),

-- Internal transfers
(22, 'WH/INT/00001', 'internal', NULL, 1, 5, '2026-03-06', 'done',    1, '2026-03-05 09:00:00'),
(23, 'WH/INT/00002', 'internal', NULL, 5, 8, '2026-03-15', 'ready',   1, '2026-03-14 11:00:00'),
(24, 'WH/INT/00003', 'internal', NULL, 1, 9, '2026-03-17', 'draft',   1, '2026-03-14 13:00:00')
ON DUPLICATE KEY UPDATE reference = VALUES(reference);

-- ── STOCK MOVE LINES ───────────────────────────────────────────
INSERT INTO stock_move_lines (id, move_id, product_id, quantity) VALUES
-- WH/IN/00001 (done receipt)
(1,  1,  1, 20),  (2,  1,  3, 50),
-- WH/IN/00002
(3,  2,  5, 15),  (4,  2,  6, 30),
-- WH/IN/00003
(5,  3,  2, 10),  (6,  3,  4, 40),  (7,  3,  8, 25),
-- WH/IN/00004
(8,  4,  7, 30),  (9,  4,  12, 100),
-- WH/IN/00005
(10, 5,  13, 200), (11, 5,  14, 20),
-- WH/IN/00006 (ready receipt)
(12, 6,  1, 25),  (13, 6,  9, 40),
-- WH/IN/00007
(14, 7,  3, 30),  (15, 7,  10, 15),
-- WH/IN/00008 (draft)
(16, 8,  6, 20),  (17, 8,  15, 50),
-- WH/IN/00009 (late receipt)
(18, 9,  4, 60),  (19, 9,  8, 30),
-- WH/IN/00010 (late)
(20, 10, 11, 10), (21, 10, 7, 15),
-- WH/IN/00011 (waiting)
(22, 11, 2, 12),  (23, 11, 1, 8),
-- WH/OUT/00001 (done delivery)
(24, 12, 1, 10),  (25, 12, 3, 20),
-- WH/OUT/00002
(26, 13, 7, 15),  (27, 13, 8, 40),
-- WH/OUT/00003
(28, 14, 2, 5),   (29, 14, 6, 10),
-- WH/OUT/00004
(30, 15, 4, 25),  (31, 15, 15, 15),
-- WH/OUT/00005 (ready delivery)
(32, 16, 1, 12),  (33, 16, 3, 35),  (34, 16, 9, 10),
-- WH/OUT/00006
(35, 17, 7, 20),  (36, 17, 12, 50),
-- WH/OUT/00007 (late delivery)
(37, 18, 5, 8),   (38, 18, 14, 10),
-- WH/OUT/00008 (late)
(39, 19, 4, 30),  (40, 19, 15, 20),
-- WH/OUT/00009 (waiting)
(41, 20, 1, 15),  (42, 20, 11, 5),
-- WH/OUT/00010 (waiting)
(43, 21, 13, 150),(44, 21, 6, 10),
-- WH/INT/00001 (done internal)
(45, 22, 3, 20),  (46, 22, 8, 15),
-- WH/INT/00002 (ready internal)
(47, 23, 4, 30),  (48, 23, 12, 40),
-- WH/INT/00003 (draft internal)
(49, 24, 7, 10),  (50, 24, 9, 20)
ON DUPLICATE KEY UPDATE quantity = VALUES(quantity);

-- ── MOVE HISTORY (for completed operations) ────────────────────
INSERT INTO move_history (id, move_id, product_id, from_location_id, to_location_id, quantity, move_date) VALUES
-- WH/IN/00001
(1,  1,  1, NULL, 1, 20, '2026-02-10 09:30:00'),
(2,  1,  3, NULL, 1, 50, '2026-02-10 09:30:00'),
-- WH/IN/00002
(3,  2,  5, NULL, 2, 15, '2026-02-15 15:00:00'),
(4,  2,  6, NULL, 2, 30, '2026-02-15 15:00:00'),
-- WH/IN/00003
(5,  3,  2, NULL, 5, 10, '2026-02-20 10:30:00'),
(6,  3,  4, NULL, 5, 40, '2026-02-20 10:30:00'),
(7,  3,  8, NULL, 5, 25, '2026-02-20 10:30:00'),
-- WH/IN/00004
(8,  4,  7, NULL, 1, 30, '2026-03-01 16:30:00'),
(9,  4,  12, NULL, 1, 100, '2026-03-01 16:30:00'),
-- WH/IN/00005
(10, 5,  13, NULL, 6, 200, '2026-03-05 11:30:00'),
(11, 5,  14, NULL, 6, 20,  '2026-03-05 11:30:00'),
-- WH/OUT/00001
(12, 12, 1, 1, NULL, 10, '2026-02-12 08:30:00'),
(13, 12, 3, 1, NULL, 20, '2026-02-12 08:30:00'),
-- WH/OUT/00002
(14, 13, 7, 1, NULL, 15, '2026-02-18 09:30:00'),
(15, 13, 8, 1, NULL, 40, '2026-02-18 09:30:00'),
-- WH/OUT/00003
(16, 14, 2, 5, NULL, 5,  '2026-02-25 11:30:00'),
(17, 14, 6, 5, NULL, 10, '2026-02-25 11:30:00'),
-- WH/OUT/00004
(18, 15, 4, 8, NULL, 25, '2026-03-03 07:30:00'),
(19, 15, 15, 8, NULL, 15, '2026-03-03 07:30:00'),
-- WH/INT/00001
(20, 22, 3, 1, 5, 20, '2026-03-06 09:30:00'),
(21, 22, 8, 1, 5, 15, '2026-03-06 09:30:00')
ON DUPLICATE KEY UPDATE quantity = VALUES(quantity);
