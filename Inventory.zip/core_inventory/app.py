"""
CoreInventory — Flask Application
==================================
Run:  python app.py
Visit: http://127.0.0.1:5000/login
"""

from flask import Flask, redirect, url_for, session
from flask_mail import Mail
from werkzeug.security import generate_password_hash
from models import db, User, PasswordResetToken
import email_config

app = Flask(__name__)
app.secret_key = 'dev-secret-key-change-in-production'

# MySQL database connection
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/core_inventory'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# ── Email / Flask-Mail config ──
app.config['MAIL_SERVER'] = email_config.MAIL_SERVER
app.config['MAIL_PORT'] = email_config.MAIL_PORT
app.config['MAIL_USE_TLS'] = email_config.MAIL_USE_TLS
app.config['MAIL_USE_SSL'] = email_config.MAIL_USE_SSL
app.config['MAIL_USERNAME'] = email_config.MAIL_USERNAME
app.config['MAIL_PASSWORD'] = email_config.MAIL_PASSWORD
app.config['MAIL_DEFAULT_SENDER'] = email_config.MAIL_DEFAULT_SENDER

# Initialize extensions
db.init_app(app)
mail = Mail(app)

# Import and register blueprints AFTER app is created
from auth_routes import auth_bp
from dashboard import dashboard_bp
from stock import stock_bp
from operations import operations_bp
from settings import settings_bp

app.register_blueprint(auth_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(stock_bp)
app.register_blueprint(operations_bp)
app.register_blueprint(settings_bp)


@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard.index'))
    return redirect(url_for('auth.login'))


# Auto-create tables & seed a demo user on first run
with app.app_context():
    try:
        db.create_all()  # Creates password_reset_tokens (and any other missing tables)
        if User.query.count() == 0:
            demo = User(
                login_id='admin0',
                email='admin@coreinventory.com',
                password_hash=generate_password_hash('Admin@123'),
            )
            db.session.add(demo)
            db.session.commit()
            print('[OK] Demo user created -> admin0 / Admin@123')
    except Exception as e:
        print(f'[INFO] Could not seed user: {e}')


if __name__ == '__main__':
    app.run(debug=True)
